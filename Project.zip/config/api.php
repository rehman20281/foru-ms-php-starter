<?php
return [
    'api_key' => 'e96779a0-3fb6-43eb-b719-88396fed5123',
    'authorization' => 'Bearer 123',
    'posts' => 'https://foru-ms.vercel.app/api/v1/posts',
    'user_signup' => 'https://foru-ms.vercel.app/api/v1/auth/register',
    'user_login' => 'https://foru-ms.vercel.app/api/v1/auth/login',
    'get_user' => 'https://foru-ms.vercel.app/api/v1/auth/me',
    'create_thread' => 'https://foru-ms.vercel.app/api/v1/thread',
    'threads' => 'https://foru-ms.vercel.app/api/v1/threads',
    'thread_by_id' => 'https://foru-ms.vercel.app/api/v1/thread/',
    'thread_posts' => 'https://foru-ms.vercel.app/api/v1/thread/%s/posts',
    'user_by_id' => 'https://foru-ms.vercel.app/api/v1/user/',
    'create_post' => 'https://foru-ms.vercel.app/api/v1/post',
];
