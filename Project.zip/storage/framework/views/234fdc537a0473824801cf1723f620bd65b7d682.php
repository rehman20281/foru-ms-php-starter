<?php $__env->startSection('content'); ?>
    <div class="w-full">
        <div class="w-full px-6">
            <div class="lg:flex flex-wrap">
                <div class="py-10 lg:w-2/3 w-full md:pr-6 sm:border-r border-gray-300">
                    <a href="/">
                        <div class="flex items-center">
                            <div
                                class="mr-3 w-6 h-6 rounded-full text-gray-500 border border-gray-500 flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                     class="icon icon-tabler icon-tabler-chevron-left" width="18" height="18"
                                     viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z"></path>
                                    <polyline points="15 6 9 12 15 18"></polyline>
                                </svg>
                            </div>
                            <h4 class="text-xl text-gray-900">Forum Thread</h4>
                        </div>
                    </a>
                    <h1 class="my-6 text-4xl font-medium text-gray-900">
                        <?php echo e($thread?->title); ?>

                    </h1>
                    <div class="md:flex items-center">
                        <div class="w-10 h-10 rounded-full">
                            <img class="w-full h-full object-cover object-center"
                                 src="<?php echo e(asset('assets/images/enrolled-student-8.png')); ?>" alt="">
                        </div>
                        <div class="ml-2 md:mt-0 mt-4 flex items-center text-gray-600">
                            <p class="text-gray-600 text-xs">
                                by <span class="text-blue-500"><?php echo e($thread?->user?->displayName); ?></span>
                            </p>
                            <div class="w-1 h-1 bg-gray-500 rounded-full mx-2"></div>
                            <p class="text-gray-600 text-xs"><?php echo e(\Carbon\Carbon::parse($thread?->createdAt)->diffForHumans()); ?></p>
                            <div class="w-1 h-1 bg-gray-500 rounded-full mx-2"></div>
                            <p class="ml-2 text-gray-600 text-xs">
                                In: <span class="text-blue-500">Marketing</span>
                            </p>
                        </div>
                    </div>
                    <p class="mt-4 text-gray-600 text-sm">
                        <?php echo e($thread?->body); ?>

                    </p>
                    <div class="mt-8 flex items-start">
                        <div class="w-10 h-10 rounded-full flex-shrink-0">
                            <img class="w-full h-full object-cover object-center"
                                 src="<?php echo e(asset('assets/images/enrolled-student-8.png')); ?>" alt="">
                        </div>
                        <form action="<?php echo e(route('create.post')); ?>" method="post" style="display: block;width: 100%;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="threadId" value="<?php echo e($thread->id); ?>">
                            <textarea name="comment" placeholder="Reply to <?php echo e($thread?->user?->displayName); ?>'s post"
                                  class="ml-2 pl-6 pt-2 bg-gray-100 w-full h-24 resize-none focus:outline-none focus:border-blue-400 border border-transparent text-gray-800"></textarea>
                        </form>
                    </div>
                    <div class="my-8 text-gray-900 text-xl">Comments</div>
                    <?php if(count($thread?->posts) === 0): ?>
                        <div>
                            <p>No comments</p>
                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $thread?->posts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <div class="flex items-center">
                                <div class="w-10 h-10 rounded-full flex-shrink-0">
                                    <img class="w-full h-full object-cover object-center"
                                         src="<?php echo e(asset('assets/images/enrolled-student-8.png')); ?>" alt="">
                                </div>
                                <div class="ml-2 w-full">
                                    <div class="flex items-center justify-between w-full">
                                        <h5 class="text-gray-800 text-sm"><?php echo e($post?->user?->displayName); ?></h5>
                                        <p class="text-xs text-gray-600"><?php echo e(\Carbon\Carbon::parse($post->createdAt)->diffForHumans()); ?></p>
                                    </div>
                                    <p class="text-xs text-gray-600">Manager</p>
                                </div>
                            </div>
                            <p class="mt-3 text-gray-600 text-sm">
                                <?php echo e($post?->body); ?>

                            </p>
                            <div class="mt-3 flex items-center text-gray-600">
                                <a class="text-gray-600 text-xs cursor-pointer">Like</a>
                                <div class="w-1 h-1 bg-gray-500 rounded-full mx-2"></div>
                                <a class="text-gray-600 text-xs cursor-pointer">Reply</a>
                                <div class="w-1 h-1 bg-gray-500 rounded-full mx-2"></div>
                                <p class="ml-2 text-indigo-500 text-xs cursor-pointer">
                                    View replies
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr class="mt-6 mb-8 border-t border-gray-300">

                </div>
                <?php echo $__env->make('includes.recent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>

    <script>
        const textarea = document.querySelector("textarea");
        textarea.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                textarea.form.submit();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/forum/resources/views/thread_details.blade.php ENDPATH**/ ?>